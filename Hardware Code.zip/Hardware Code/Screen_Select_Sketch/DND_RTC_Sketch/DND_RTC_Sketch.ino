#include <Arduino.h>
#include <Wire.h>
#include <WiFi.h>
#include <esp_now.h>
#include "esp_wifi.h"
#include <HTTPClient.h>
#include <HardwareSerial.h>
#include <LovyanGFX.hpp>
#include <TAMC_GT911.h>

#define TFT_BL   14
#define PIR_PIN  21

static constexpr uint32_t IDLE_SLEEP_MS = 5000;

static constexpr int PIN_MOSI = 11;
static constexpr int PIN_MISO = 13;
static constexpr int PIN_SCLK = 12;
static constexpr int PIN_CS   = 10;
static constexpr int PIN_DC   = 8;
static constexpr int PIN_RST  = 9;

#define TOUCH_SDA 4
#define TOUCH_SCL 5
#define TOUCH_INT 6
#define TOUCH_RST -1

#define DF_TX 17
#define DF_RX 18

#define START_BYTE       0x7E
#define VERSION          0xFF
#define CMD_LEN          0x06
#define END_BYTE         0xEF
#define FEEDBACK         0x00
#define CMD_PLAY_TRACK   0x03
#define CMD_SET_VOLUME   0x06
#define CMD_SET_LOOP     0x08
#define CMD_PAUSE        0x0E
#define CMD_RESUME       0x0D
#define CMD_QUERY_STATUS 0x42
#define DF_BOOT_TIMEOUT  5000
#define DF_REPLY_TIMEOUT 500

#define WIFI_CHANNEL 6

const char* ssid     = "Maharansiphone";
const char* password = "ebctransistor";
const char* webhook  = "https://webhook.site/9f0ce0ad-40ae-450d-9ac5-959e61d4a666";

uint8_t receiverMAC[] = {0x80,0xB5,0x4E,0xE8,0x13,0x50};

typedef struct { uint8_t state; } Message;

#define CAL_AX -0.13627678
#define CAL_BX  1.87070680
#define CAL_CX -241.03622437
#define CAL_AY -2.12039614
#define CAL_BY  0.10725732
#define CAL_CY  425.59735107

class LGFX : public lgfx::LGFX_Device {

  lgfx::Panel_ILI9488 _panel;
  lgfx::Bus_SPI _bus;

public:

  LGFX(void) {

    {
      auto cfg = _bus.config();
      cfg.spi_host   = SPI2_HOST;
      cfg.spi_mode   = 0;
      cfg.freq_write = 16000000;
      cfg.freq_read  = 8000000;
      cfg.pin_sclk   = PIN_SCLK;
      cfg.pin_mosi   = PIN_MOSI;
      cfg.pin_miso   = PIN_MISO;
      cfg.pin_dc     = PIN_DC;

      _bus.config(cfg);
      _panel.setBus(&_bus);
    }

    {
      auto cfg = _panel.config();

      cfg.pin_cs        = PIN_CS;
      cfg.pin_rst       = PIN_RST;
      cfg.pin_busy      = -1;

      cfg.memory_width  = 320;
      cfg.memory_height = 480;
      cfg.panel_width   = 320;
      cfg.panel_height  = 480;

      cfg.offset_x      = 0;
      cfg.offset_y      = 0;

      cfg.readable      = false;
      cfg.invert        = false;
      cfg.rgb_order     = false;
      cfg.dlen_16bit    = false;
      cfg.bus_shared    = false;

      _panel.config(cfg);
    }

    setPanel(&_panel);
  }
};

LGFX lcd;
TAMC_GT911 touch(TOUCH_SDA, TOUCH_SCL, TOUCH_INT, TOUCH_RST, 320, 480);

HardwareSerial dfSerial(1);

int selected = -1;

bool screenAwake = true;

uint32_t lastActivity = 0;
uint32_t lastTouchMs  = 0;

volatile bool webhookPending = false;
volatile uint8_t webhookPendingState = 0;

void webhookTask(void* param)
{
  for (;;)
  {
    if (webhookPending)
    {
      webhookPending = false;

      uint8_t state = webhookPendingState;

      if (WiFi.status() == WL_CONNECTED)
      {
        HTTPClient http;

        http.begin(webhook);

        http.addHeader("Content-Type","application/json");

        String label =
          (state == 1) ? "Ready to Clean" :
                         "Do Not Disturb";

        String payload =
          "{\"state\":" + String(state) +
          ",\"label\":\"" + label + "\"}";

        http.POST(payload);

        http.end();
      }
    }

    vTaskDelay(50 / portTICK_PERIOD_MS);
  }
}

void sendDFCommand(uint8_t cmd,uint8_t param1,uint8_t param2)
{
  uint16_t checksum = -(VERSION + CMD_LEN + cmd + FEEDBACK + param1 + param2);

  uint8_t packet[10] =
  {
    START_BYTE,
    VERSION,
    CMD_LEN,
    cmd,
    FEEDBACK,
    param1,
    param2,
    (uint8_t)(checksum >> 8),
    (uint8_t)(checksum & 0xFF),
    END_BYTE
  };

  dfSerial.write(packet,10);
}

void dfFlush()
{
  while (dfSerial.available())
    dfSerial.read();
}

bool waitForReply(uint32_t timeout = DF_REPLY_TIMEOUT)
{
  uint32_t start = millis();

  while (millis() - start < timeout)
  {
    if (dfSerial.available() && dfSerial.peek() == START_BYTE)
      return true;

    delay(10);
  }

  return false;
}

bool waitForDFPlayer()
{
  uint32_t start = millis();

  while (millis() - start < DF_BOOT_TIMEOUT)
  {
    dfFlush();

    sendDFCommand(CMD_QUERY_STATUS,0x00,0x00);

    if (waitForReply(300))
    {
      dfFlush();
      return true;
    }

    delay(200);
  }

  return false;
}

void dfSetVolume(uint8_t vol)
{
  sendDFCommand(CMD_SET_VOLUME,0x00,vol);
  delay(50);
}

void dfPlayTrack(uint8_t track)
{
  sendDFCommand(CMD_PLAY_TRACK,0x00,track);
  delay(50);
}

void dfPause()
{
  sendDFCommand(CMD_PAUSE,0x00,0x00);
  delay(50);
}

void dfResume()
{
  sendDFCommand(CMD_RESUME,0x00,0x00);
  delay(50);
}

static inline int clampi(int v,int lo,int hi)
{
  if (v < lo) return lo;
  if (v > hi) return hi;
  return v;
}

void rawToScreen(int rx,int ry,int &x,int &y)
{
  x = (int)(CAL_AX * rx + CAL_BX * ry + CAL_CX);
  y = (int)(CAL_AY * rx + CAL_BY * ry + CAL_CY);

  x = clampi(x,0,lcd.width()-1);
  y = clampi(y,0,lcd.height()-1);
}

uint8_t hitTest(int x)
{
  int w = lcd.width() / 2;

  if (x < w) return 1;
  return 2;
}

void drawUI()
{
  int w = lcd.width();
  int h = lcd.height();
  int pw = w / 2;

  struct
  {
    uint8_t state;
    uint16_t on;
    const char* l1;
    const char* l2;

  } panels[2] =
  {
    {1,TFT_GREEN,"Ready to","Clean"},
    {2,TFT_RED,"Do Not","Disturb"}
  };

  for (int i=0;i<2;i++)
  {
    bool active = (selected == (int)panels[i].state);

    uint16_t bg = active ? panels[i].on : TFT_BLACK;
    uint16_t fg = active ? TFT_BLACK : TFT_WHITE;

    lcd.fillRect(i*pw,0,pw,h,bg);

    lcd.setTextColor(fg,bg);

    lcd.setTextSize(2);

    int fh = lcd.fontHeight();

    int x0 = i*pw;

    int tw = lcd.textWidth(panels[i].l1);

    lcd.setCursor(x0 + (pw - tw)/2, h/2 - fh);

    lcd.print(panels[i].l1);

    tw = lcd.textWidth(panels[i].l2);

    lcd.setCursor(x0 + (pw - tw)/2, h/2);

    lcd.print(panels[i].l2);
  }

  lcd.drawLine(pw,0,pw,h-1,TFT_WHITE);
}

void doScreenOff()
{
  if (!screenAwake) return;

  screenAwake = false;

  digitalWrite(TFT_BL,LOW);

  dfPause();
}

void doScreenOn()
{
  if (screenAwake) return;

  screenAwake = true;

  digitalWrite(TFT_BL,HIGH);

  drawUI();

  if (selected != -1)
    dfResume();
}

void sendESPNow(uint8_t state)
{
  Message msg;

  msg.state = state;

  esp_now_send(receiverMAC,(uint8_t*)&msg,sizeof(msg));

  delay(100);
}

void triggerWebhook(uint8_t state)
{
  webhookPendingState = state;

  webhookPending = true;
}

void setup()
{
  Serial.begin(115200);

  pinMode(TFT_BL,OUTPUT);

  pinMode(PIR_PIN,INPUT);

  digitalWrite(TFT_BL,HIGH);

  lcd.init();

  lcd.setRotation(1);

  lcd.fillScreen(TFT_BLACK);

  Wire.begin(TOUCH_SDA,TOUCH_SCL);

  Wire.setClock(400000);

  touch.begin();

  touch.setRotation(1);

  lcd.setTextColor(TFT_WHITE,TFT_BLACK);

  lcd.setTextSize(2);

  lcd.setCursor(100,220);

  lcd.print("Booting...");

  dfSerial.begin(9600,SERIAL_8N1,DF_RX,DF_TX);

  if (!waitForDFPlayer())
  {
    lcd.fillScreen(TFT_BLACK);

    lcd.setTextColor(TFT_RED,TFT_BLACK);

    lcd.setCursor(60,220);

    lcd.print("DFPlayer FAIL");

    while(true);
  }

  dfSetVolume(25);

  WiFi.mode(WIFI_STA);

  WiFi.begin(ssid,password);

  uint32_t wifiStart = millis();

  while (WiFi.status() != WL_CONNECTED && millis() - wifiStart < 10000)
  {
    delay(300);
  }

  esp_wifi_set_channel(WIFI_CHANNEL,WIFI_SECOND_CHAN_NONE);

  esp_now_init();

  esp_now_peer_info_t peer = {};

  memcpy(peer.peer_addr,receiverMAC,6);

  peer.channel = WIFI_CHANNEL;

  peer.encrypt = false;

  esp_now_add_peer(&peer);

  xTaskCreatePinnedToCore(webhookTask,"webhook",8192,NULL,1,NULL,0);

  drawUI();

  screenAwake = true;

  lastActivity = millis();
}

void loop()
{
  uint32_t now = millis();

  bool motionDetected = (digitalRead(PIR_PIN) == HIGH);

  if (motionDetected)
  {
    lastActivity = now;

    if (!screenAwake)
    {
      doScreenOn();

      delay(150);
    }
  }

  if (screenAwake && (now - lastActivity >= IDLE_SLEEP_MS))
  {
    doScreenOff();
  }

  if (!screenAwake)
  {
    delay(20);
    return;
  }

  touch.read();

  if (!touch.isTouched)
  {
    delay(10);
    return;
  }

  if (now - lastTouchMs < 180)
    return;

  lastTouchMs = now;

  lastActivity = now;

  int rx = touch.points[0].x;
  int ry = touch.points[0].y;

  int x,y;

  rawToScreen(rx,ry,x,y);

  uint8_t tapped = hitTest(x);

  if ((int)tapped != selected)
  {
    selected = tapped;

    drawUI();

    dfPlayTrack(tapped);

    sendESPNow(tapped);

    triggerWebhook(tapped);
  }

  while(true)
  {
    touch.read();

    if (!touch.isTouched)
      break;

    delay(10);
  }
}