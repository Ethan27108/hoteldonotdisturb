#include <Arduino.h>
#include <Wire.h>
#include <WiFi.h>
#include <esp_now.h>
#include "esp_wifi.h"
#include <HTTPClient.h>
#include <HardwareSerial.h>
#include <LovyanGFX.hpp>
#include <TAMC_GT911.h>

#define TFT_BL   14
#define PIR_PIN  21

static constexpr uint32_t IDLE_SLEEP_MS = 5000;

static constexpr int PIN_MOSI = 11;
static constexpr int PIN_MISO = 13;
static constexpr int PIN_SCLK = 12;
static constexpr int PIN_CS   = 10;
static constexpr int PIN_DC   = 8;
static constexpr int PIN_RST  = 9;

#define TOUCH_SDA 4
#define TOUCH_SCL 5
#define TOUCH_INT 6
#define TOUCH_RST -1

#define DF_TX 17
#define DF_RX 18

#define START_BYTE       0x7E
#define VERSION          0xFF
#define CMD_LEN          0x06
#define END_BYTE         0xEF
#define FEEDBACK         0x00
#define CMD_PLAY_TRACK   0x03
#define CMD_SET_VOLUME   0x06
#define CMD_SET_LOOP     0x08
#define CMD_PAUSE        0x0E
#define CMD_RESUME       0x0D

#define WIFI_CHANNEL 6

const char* ssid     = "Ethan27108";
const char* password = "capstone2";
const char* webhook  = "https://hoteldonotdisturb.tech/api/button/";

uint8_t receiverMAC[] = {0x80,0xB5,0x4E,0xE8,0x13,0x50};

typedef struct { uint8_t state; } Message;

#define CAL_AX -0.13627678
#define CAL_BX  1.87070680
#define CAL_CX -241.03622437
#define CAL_AY -2.12039614
#define CAL_BY  0.10725732
#define CAL_CY  425.59735107

class LGFX : public lgfx::LGFX_Device {

  lgfx::Panel_ILI9488 _panel;
  lgfx::Bus_SPI _bus;

public:

  LGFX(void){

    {
      auto cfg = _bus.config();
      cfg.spi_host   = SPI2_HOST;
      cfg.spi_mode   = 0;
      cfg.freq_write = 16000000;
      cfg.freq_read  = 8000000;
      cfg.pin_sclk   = PIN_SCLK;
      cfg.pin_mosi   = PIN_MOSI;
      cfg.pin_miso   = PIN_MISO;
      cfg.pin_dc     = PIN_DC;

      _bus.config(cfg);
      _panel.setBus(&_bus);
    }

    {
      auto cfg = _panel.config();
      cfg.pin_cs        = PIN_CS;
      cfg.pin_rst       = PIN_RST;
      cfg.pin_busy      = -1;
      cfg.memory_width  = 320;
      cfg.memory_height = 480;
      cfg.panel_width   = 320;
      cfg.panel_height  = 480;

      _panel.config(cfg);
    }

    setPanel(&_panel);
  }
};

LGFX lcd;
TAMC_GT911 touch(TOUCH_SDA, TOUCH_SCL, TOUCH_INT, TOUCH_RST, 320, 480);
HardwareSerial dfSerial(1);

int selected=-1;
bool screenAwake=true;
bool muted=false;

uint32_t lastActivity=0;
uint32_t lastTouchMs=0;

volatile bool webhookPending=false;
volatile uint8_t webhookPendingState=0;

bool wifiConnected=false;



void showConnectingScreen(int dots){

  lcd.fillScreen(TFT_BLACK);

  lcd.setTextSize(2);
  lcd.setTextColor(TFT_WHITE);

  lcd.setCursor(60,200);
  lcd.print("Connecting to Network");

  lcd.setCursor(120,240);
  lcd.print("Retrying");

  for(int i=0;i<dots;i++) lcd.print(".");
}



void waitForInternet(){

  int dots=0;

  while(WiFi.status()!=WL_CONNECTED){

    showConnectingScreen(dots);

    dots++;
    if(dots>3) dots=0;

    WiFi.disconnect();
    WiFi.begin(ssid,password);

    uint32_t startAttempt=millis();

    while(WiFi.status()!=WL_CONNECTED && millis()-startAttempt<5000){
      delay(300);
    }
  }

  wifiConnected=true;

  lcd.fillScreen(TFT_BLACK);
}



void maintainWiFi(){

  if(WiFi.status()==WL_CONNECTED) return;

  wifiConnected=false;

  waitForInternet();
}



void webhookTask(void* param){

  for(;;){

    if(webhookPending){

      webhookPending=false;

      uint8_t state=webhookPendingState;

      if(WiFi.status()==WL_CONNECTED){

        HTTPClient http;

        http.begin(webhook);
        http.addHeader("Content-Type","application/json");

        int room_id=1;

        String status=(state==1)?"dirty":
                      (state==2)?"do_not_disturb":"clean";

        String payload="{\"room_id\":"+String(room_id)+",\"status\":\""+status+"\"}";

        http.POST(payload);
        http.end();
      }
    }

    vTaskDelay(50/portTICK_PERIOD_MS);
  }
}



void sendDFCommand(uint8_t cmd,uint8_t p1,uint8_t p2){

  uint16_t checksum=-(VERSION+CMD_LEN+cmd+FEEDBACK+p1+p2);

  uint8_t packet[10]={
    START_BYTE,VERSION,CMD_LEN,cmd,FEEDBACK,
    p1,p2,
    (uint8_t)(checksum>>8),(uint8_t)(checksum&0xFF),
    END_BYTE
  };

  dfSerial.write(packet,10);
}



void dfPause(){sendDFCommand(CMD_PAUSE,0,0);}
void dfResume(){sendDFCommand(CMD_RESUME,0,0);}
void dfSetVolume(uint8_t v){sendDFCommand(CMD_SET_VOLUME,0,v);}
void dfPlayTrack(uint8_t t){sendDFCommand(CMD_PLAY_TRACK,0,t);}



static inline int clampi(int v,int lo,int hi){

  if(v<lo)return lo;
  if(v>hi)return hi;
  return v;
}



void rawToScreen(int rx,int ry,int &x,int &y){

  x=(int)(CAL_AX*rx+CAL_BX*ry+CAL_CX);
  y=(int)(CAL_AY*rx+CAL_BY*ry+CAL_CY);

  x=clampi(x,0,lcd.width()-1);
  y=clampi(y,0,lcd.height()-1);
}



// Panels left-to-right: Do Not Disturb | Mute | Ready to Clean
uint8_t hitTest(int x){

  int w=lcd.width()/3;

  if(x<w) return 2;    // Do Not Disturb
  if(x<w*2) return 4;  // Mute
  return 1;             // Ready to Clean
}



void drawUI(){

  int w=lcd.width();
  int h=lcd.height();
  int pw=w/3;

  struct{
    uint8_t state;
    uint16_t on;
    const char* l1;
    const char* l2;
  } panels[3]={
    {2,TFT_RED,"Do Not","Disturb"},
    {4,TFT_YELLOW,"Mute",""},
    {1,TFT_GREEN,"Ready to","Clean"}
  };

  for(int i=0;i<3;i++){

    bool active=(selected==panels[i].state)||
                (panels[i].state==4 && muted);

    uint16_t bg=active?panels[i].on:TFT_BLACK;
    uint16_t fg=active?TFT_BLACK:TFT_WHITE;

    lcd.fillRect(i*pw,0,pw,h,bg);

    lcd.setTextColor(fg,bg);
    lcd.setTextSize(2);

    int fh=lcd.fontHeight();
    int x0=i*pw;

    int tw=lcd.textWidth(panels[i].l1);

    lcd.setCursor(x0+(pw-tw)/2,h/2-fh);
    lcd.print(panels[i].l1);

    if(strlen(panels[i].l2)>0){

      tw=lcd.textWidth(panels[i].l2);

      lcd.setCursor(x0+(pw-tw)/2,h/2);
      lcd.print(panels[i].l2);
    }
  }

  lcd.drawLine(pw,0,pw,h-1,TFT_WHITE);
  lcd.drawLine(pw*2,0,pw*2,h-1,TFT_WHITE);
}



void doScreenOff(){

  if(!screenAwake)return;

  screenAwake=false;

  digitalWrite(TFT_BL,LOW);

  dfPause();
}



void doScreenOn(){

  if(screenAwake)return;

  screenAwake=true;

  digitalWrite(TFT_BL,HIGH);

  drawUI();

  if(selected!=-1 && !muted) dfResume();
}



void sendESPNow(uint8_t state){

  Message msg;
  msg.state=state;

  esp_now_send(receiverMAC,(uint8_t*)&msg,sizeof(msg));

  delay(100);
}



void triggerWebhook(uint8_t state){

  webhookPendingState=state;
  webhookPending=true;
}



void setup(){

  Serial.begin(115200);

  pinMode(TFT_BL,OUTPUT);
  pinMode(PIR_PIN,INPUT);

  digitalWrite(TFT_BL,HIGH);

  lcd.init();
  lcd.setRotation(3);  // rotated 180° from original
  lcd.fillScreen(TFT_BLACK);

  Wire.begin(TOUCH_SDA,TOUCH_SCL);
  Wire.setClock(400000);

  touch.begin();
  touch.setRotation(3);  // rotated 180° from original

  dfSerial.begin(9600,SERIAL_8N1,DF_RX,DF_TX);

  dfSetVolume(25);

  WiFi.mode(WIFI_STA);

  waitForInternet();

  esp_wifi_set_channel(WIFI_CHANNEL,WIFI_SECOND_CHAN_NONE);

  esp_now_init();

  esp_now_peer_info_t peer={};

  memcpy(peer.peer_addr,receiverMAC,6);
  peer.channel=WIFI_CHANNEL;
  peer.encrypt=false;

  esp_now_add_peer(&peer);

  xTaskCreatePinnedToCore(webhookTask,"webhook",8192,NULL,1,NULL,0);

  drawUI();

  lastActivity=millis();
}



void loop(){

  maintainWiFi();

  uint32_t now=millis();

  bool motionDetected=(digitalRead(PIR_PIN)==HIGH);

  if(motionDetected){

    lastActivity=now;

    if(!screenAwake){

      doScreenOn();
      delay(150);
    }
  }

  if(screenAwake && now-lastActivity>=IDLE_SLEEP_MS){
    doScreenOff();
  }

  if(!screenAwake){
    delay(20);
    return;
  }

  touch.read();

  if(!touch.isTouched){
    delay(10);
    return;
  }

  if(now-lastTouchMs<180) return;

  lastTouchMs=now;
  lastActivity=now;

  int rx=touch.points[0].x;
  int ry=touch.points[0].y;

  int x,y;

  rawToScreen(rx,ry,x,y);

  uint8_t tapped=hitTest(x);

  if(tapped==4){

    muted=!muted;

    if(muted) dfPause();
    else if(selected!=-1) dfResume();

    drawUI();
  }

  else if((int)tapped!=selected){

    selected=tapped;

    drawUI();

    if(!muted) dfPlayTrack(tapped);

    sendESPNow(tapped);

    triggerWebhook(tapped);
  }

  while(true){

    touch.read();

    if(!touch.isTouched) break;

    delay(10);
  }
}