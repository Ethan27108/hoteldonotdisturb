#include <Arduino.h>
#include <WiFi.h>
#include <esp_now.h>
#include <HTTPClient.h>
#include <HardwareSerial.h>
#include "esp_wifi.h"

HardwareSerial dfSerial(1);

#define DF_TX 17
#define DF_RX 18

#define LED_CLEAN  6
#define LED_DND    7
#define MOTION_PIN 8
#define BTN_CLEAN  4
#define BTN_DND    5

#define START_BYTE       0x7E
#define VERSION          0xFF
#define CMD_LEN          0x06
#define END_BYTE         0xEF
#define FEEDBACK         0x00

#define CMD_PLAY_TRACK   0x03
#define CMD_SET_VOLUME   0x06
#define CMD_PAUSE        0x0E
#define CMD_RESUME       0x0D
#define CMD_QUERY_STATUS 0x42

#define DF_BOOT_TIMEOUT  5000
#define DF_REPLY_TIMEOUT 500
#define MOTION_TIMEOUT   5000

#define WIFI_CHANNEL     6

const char* ssid     = "Ethan27108";
const char* password = "capstone2";
const char* webhook  = "https://hoteldonotdisturb.tech/api/button/";

uint8_t receiverMAC[] = {0x80, 0xB5, 0x4E, 0xE8, 0x13, 0x50};

typedef struct {
  uint8_t state;
} Message;

uint8_t currentState = 0;
bool audioOn         = false;
uint32_t lastMotion  = 0;

bool wifiConnected = false;

// ── DFPlayer ─────────────────────────────────────────────────

void sendDFCommand(uint8_t cmd, uint8_t param1, uint8_t param2) {
  uint16_t checksum = -(VERSION + CMD_LEN + cmd + FEEDBACK + param1 + param2);
  uint8_t packet[10] = {
    START_BYTE, VERSION, CMD_LEN, cmd, FEEDBACK,
    param1, param2,
    (uint8_t)(checksum >> 8), (uint8_t)(checksum & 0xFF),
    END_BYTE
  };
  dfSerial.write(packet, 10);
}

void dfFlush() { while (dfSerial.available()) dfSerial.read(); }

bool waitForReply(uint32_t timeout = DF_REPLY_TIMEOUT) {
  uint32_t start = millis();
  while (millis() - start < timeout) {
    if (dfSerial.available() && dfSerial.peek() == START_BYTE) return true;
    delay(10);
  }
  return false;
}

bool waitForDFPlayer() {
  uint32_t start = millis();
  while (millis() - start < DF_BOOT_TIMEOUT) {
    dfFlush();
    sendDFCommand(CMD_QUERY_STATUS, 0x00, 0x00);
    if (waitForReply(300)) { dfFlush(); return true; }
    delay(200);
  }
  return false;
}

void dfSetVolume(uint8_t vol) { sendDFCommand(CMD_SET_VOLUME, 0x00, vol); delay(50); }
void dfPlayTrack(uint16_t track) { sendDFCommand(CMD_PLAY_TRACK, (uint8_t)(track >> 8), (uint8_t)(track & 0xFF)); delay(50); }
void dfPause() { sendDFCommand(CMD_PAUSE, 0x00, 0x00); delay(50); }
void dfResume() { sendDFCommand(CMD_RESUME, 0x00, 0x00); delay(50); }

// ── ESP-NOW ─────────────────────────────────────────────────

void sendESPNow(uint8_t state) {
  Message msg;
  msg.state = state;
  esp_now_send(receiverMAC, (uint8_t*)&msg, sizeof(msg));
  delay(200);
}

// ── Webhook ─────────────────────────────────────────────────

void sendWebhook(uint8_t state) {

  if (WiFi.status() != WL_CONNECTED) return;

  HTTPClient http;
  http.begin(webhook);
  http.addHeader("Content-Type", "application/json");

  int room_id = 34;

  String status = (state == 1) ? "dirty" :
                  (state == 2) ? "do_not_disturb" : "clean";

  String payload = "{\"room_id\":" + String(room_id) +
                   ",\"status\":\"" + status + "\"}";

  http.POST(payload);
  http.end();
}

// ── WiFi WAIT + LED STATUS ─────────────────────────────────

void waitForWiFi(){

  WiFi.mode(WIFI_STA);

  while(WiFi.status() != WL_CONNECTED){

    WiFi.begin(ssid,password);

    uint32_t attemptStart = millis();

    while(WiFi.status() != WL_CONNECTED && millis() - attemptStart < 5000){

      digitalWrite(LED_CLEAN,HIGH);
      digitalWrite(LED_DND,HIGH);
      delay(300);

      digitalWrite(LED_CLEAN,LOW);
      digitalWrite(LED_DND,LOW);
      delay(300);
    }
  }

  wifiConnected = true;

  digitalWrite(LED_CLEAN,HIGH);
  digitalWrite(LED_DND,HIGH);

  delay(5000);

  digitalWrite(LED_CLEAN,LOW);
  digitalWrite(LED_DND,LOW);
}

// ── Sleep / Wake ───────────────────────────────────────────

void goToSleep() {
  audioOn = false;
  digitalWrite(LED_CLEAN, LOW);
  digitalWrite(LED_DND,   LOW);
  dfPause();
}

void wakeUp() {
  audioOn    = true;
  lastMotion = millis();

  if (currentState == 1) {
    digitalWrite(LED_CLEAN, HIGH);
    digitalWrite(LED_DND, LOW);
    dfPlayTrack(1);
  }

  else if (currentState == 2) {
    digitalWrite(LED_CLEAN, LOW);
    digitalWrite(LED_DND, HIGH);
    dfPlayTrack(2);
  }

  else if (currentState == 3) {
    digitalWrite(LED_CLEAN, HIGH);
    digitalWrite(LED_DND, HIGH);
    dfPlayTrack(3);
  }
}

// ── State handler ──────────────────────────────────────────

void applyState(uint8_t state) {

  if (state == currentState) return;

  currentState = state;
  audioOn      = true;
  lastMotion   = millis();

  if (state == 1) {
    digitalWrite(LED_CLEAN, HIGH);
    digitalWrite(LED_DND, LOW);
    dfPlayTrack(1);
  }

  else if (state == 2) {
    digitalWrite(LED_CLEAN, LOW);
    digitalWrite(LED_DND, HIGH);
    dfPlayTrack(2);
  }

  else if (state == 3) {
    digitalWrite(LED_CLEAN, HIGH);
    digitalWrite(LED_DND, HIGH);
    dfPlayTrack(3);
  }
}

// ── Setup ──────────────────────────────────────────────────

void setup() {

  pinMode(LED_CLEAN, OUTPUT);
  pinMode(LED_DND, OUTPUT);
  pinMode(MOTION_PIN, INPUT);
  pinMode(BTN_CLEAN, INPUT_PULLUP);
  pinMode(BTN_DND, INPUT_PULLUP);

  digitalWrite(LED_CLEAN, LOW);
  digitalWrite(LED_DND, LOW);

  dfSerial.begin(9600, SERIAL_8N1, DF_RX, DF_TX);

  if (!waitForDFPlayer()) {
    while (true) {
      digitalWrite(LED_CLEAN, HIGH); digitalWrite(LED_DND, HIGH); delay(100);
      digitalWrite(LED_CLEAN, LOW);  digitalWrite(LED_DND, LOW);  delay(100);
    }
  }

  dfSetVolume(25);

  waitForWiFi();

  esp_wifi_set_channel(WIFI_CHANNEL, WIFI_SECOND_CHAN_NONE);

  esp_now_init();

  esp_now_peer_info_t peer = {};
  memcpy(peer.peer_addr, receiverMAC, 6);
  peer.channel = WIFI_CHANNEL;
  peer.encrypt = false;

  esp_now_add_peer(&peer);
}

// ── Loop ──────────────────────────────────────────────────

void loop() {

  if (digitalRead(BTN_CLEAN) == LOW) {

    delay(50);

    if (digitalRead(BTN_CLEAN) == LOW) {

      applyState(1);
      sendESPNow(1);
      sendWebhook(1);

      while (digitalRead(BTN_CLEAN) == LOW);
    }
  }

  if (digitalRead(BTN_DND) == LOW) {

    delay(50);

    if (digitalRead(BTN_DND) == LOW) {

      applyState(2);
      sendESPNow(2);
      sendWebhook(2);

      while (digitalRead(BTN_DND) == LOW);
    }
  }

  if (currentState != 0) {

    bool motionDetected = digitalRead(MOTION_PIN) == HIGH;

    if (motionDetected) {
      lastMotion = millis();
      if (!audioOn) wakeUp();
    }

    if (audioOn && (millis() - lastMotion >= MOTION_TIMEOUT))
      goToSleep();
  }
}